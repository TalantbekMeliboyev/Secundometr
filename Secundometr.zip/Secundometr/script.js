let h1 = document.querySelector('h1');
let btn = document.querySelector('.btn');
let btn1 = document.querySelector('.btn1');
let btn2 = document.querySelector('.btn2');
let second = 0,
    minute = 0,
    hour = 0,
    secundometr;

h1.innerHTML = `${hour}:${minute}:${second}`;
btn.onclick = () => {
    secundometr = setInterval(() => {
        second += 1;
        if (second == 60) {
            minute += 1;
            second = 0;
        }
        if (minute == 60) {
            hour += 1;
            minute = 0;
        }
        h1.innerHTML = `${hour}:${minute}:${second}`;
    }, 100)
}
btn1.onclick = () => {
    clearInterval(secundometr);
}
btn2.onclick = () => {
    clearInterval(secundometr);
    second = 0;
    minute = 0;
    hour = 0;
    h1.innerHTML = `${hour}:${minute}:${second}`;
}